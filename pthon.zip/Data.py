print("Demonstation of built in data types")

iobj = 11
fobj = 3.14
sobj = "Hello"
bobj = True

print(iobj)
print(fobj)
print(sobj)
print(bobj)

print(type(iobj))
print(type(fobj))
print(type(sobj))
print(type(bobj))
