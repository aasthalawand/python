from Numbers import *
from sys import *

def main():
    DisplayFactors(int(argv[1]))

if __name__ == "__main__":
    main()

# python Factors6.py 12