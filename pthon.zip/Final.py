print("Marvellous Infosystems")

def main():
    print("Jay Ganesh...")
    print("Inside main")

if __name__ == "__main__":
    print("Inside starter")
    main()      # Function call

print("End of program")