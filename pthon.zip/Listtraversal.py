print("________________________")
values = [10,20,30,40,50]

print(values[0])
print(values[1])
print(values[2])
print(values[3])
print(values[4])

print("________________________")

for i in range(0,len(values)):
    print(values[i])

print("________________________")

for no in values:
    print(no)

print("________________________")