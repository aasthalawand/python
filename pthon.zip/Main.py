# Function defination
def main():
    print("Jay Ganesh...")

main()  # Function call