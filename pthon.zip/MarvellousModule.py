def Addition(Value1, Value2):
    print("Value of __name__ from Addition is : ",__name__)
    Ans = Value1 + Value2
    return Ans