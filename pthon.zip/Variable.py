print("Demonstration of variable creation")

no = 11
print("Value of no is : ",no)
print("Data type of no is : ",type(no))

marks = 62.5
print("Value of marks is : ",marks)
print("Data type of marks is : ",type(marks))

Mobile = True
print("Value of Mobile is : ",Mobile)
print("Data type of Mobile is : ",type(Mobile))

City = "Pune"
print("Value of City is : ",City)
print("Data type of City is : ",type(City))