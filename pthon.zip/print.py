print("Hello world")

print("A")
print("B")
print("C")


print("A", end = "")
print("B", end = "")
print("C", end = "")

print()

print("A", end = "\t")
print("B", end = "\t")
print("C", end = "\t")

print()

print("A", end = "*")
print("B", end = "*")
print("C", end = "*")

print()
