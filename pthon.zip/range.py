
# range(start, end, displacement)
# start :  is by default ____
# end : There is no default value
# displcement : is by default 1

range(1,5)  #   1   2   3   4
range(1,5,1)    #   1   2   3   4
range(1,10,2)   #   1   3   5   7   9