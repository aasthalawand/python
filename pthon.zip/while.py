print("Hello")
print("Hello")
print("Hello")
print("Hello")

i = 0

while i < 7:
    print("World")
    print(i)
    i = i + 1